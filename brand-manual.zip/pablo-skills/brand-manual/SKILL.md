---
name: brand-manual
description: Usar este skill al crear manuales de marca, identidad visual, o brand books para cualquier cliente de Pablo — incluyendo cafeterías, restaurantes, viveros, productores de café, o cualquier negocio en Cali/Colombia. Aplica para salidas en PDF, PPTX o HTML. Clientes previos incluyen: GAITANA Café, SushiSamba, HAWAI Vivero·Restaurante.
---

Este skill guía la construcción de manuales de marca y materiales de identidad visual para clientes de producción creativa en Cali, Colombia.

## Estándares de Producción

### Formato y Layout
- **Tamaño:** A4 para PDF, Letter para documentos Word, widescreen 16:9 para PPTX
- **Márgenes:** Mínimo 2cm en todos los lados — nunca contenido tocando bordes de página
- **Estructura mínima de un brand manual:**
  1. Portada
  2. Historia / propósito de marca
  3. Logotipo: versiones, usos correctos e incorrectos
  4. Paleta de colores (con códigos HEX, RGB, CMYK)
  5. Tipografía (primaria y secundaria)
  6. Tono de voz
  7. Aplicaciones (packaging, redes, papelería, señalética)
  8. Contraportada

### Paletas de Color
- Siempre proveer HEX + RGB + CMYK
- Paletas con carácter: no defaults genéricos
- Respetar paleta del cliente si ya fue definida:
  - GAITANA: carmesí profundo + dorado
  - SushiSamba: paleta limpia con identidad fusión
  - HAWAI: tropical, natural, orgánico

### Tipografía
- Nunca usar Arial, Calibri, o fuentes genéricas de sistema
- Priorizar Google Fonts con personalidad o fuentes con licencia libre
- Siempre especificar uso: display vs. cuerpo vs. acento

## Clientes de Referencia

| Cliente | Tipo | Notas |
|---|---|---|
| GAITANA Café de Especialidad | Cafetería | Identidad regional colombiana, carmesí y dorado |
| SushiSamba | Restaurante fusión | Japonés-Brasileño-Peruano, Cali |
| HAWAI Vivero · Restaurante | Gastro-vivero | Línea de café HAWAI Café de Origen incluida |

## Entregables Comunes
- PDF brand manual (10–15 páginas)
- SVG de logotipo en versiones color / blanco / negro
- PPTX presentación de marca (10–12 slides)
- HTML admin panel o página de referencia interna

## Reglas de Calidad
- Cada página debe tener una intención visual clara
- Consistencia tipográfica a lo largo de todo el documento
- Mockups cuando sean posibles para mostrar aplicaciones reales
- Nunca dejar páginas vacías o con contenido de relleno
