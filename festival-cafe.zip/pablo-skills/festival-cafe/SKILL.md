---
name: festival-cafe
description: Usar este skill para cualquier tarea relacionada con "La Sucursal del Café" — el festival de café de especialidad planeado para julio 2026 en Palmetto Plaza, Cali. Cubre propuestas comerciales para expositores, planos de planta, cronogramas de marketing, precios de stands, comunicaciones con patrocinadores, y cualquier documento oficial del evento. Organizadores: Médium Café y Elixir Café.
---

Este skill guía la producción de materiales comerciales y operativos para **La Sucursal del Café**, festival de café de especialidad organizado por Médium Café y Elixir Café.

## Contexto del Evento

- **Nombre:** La Sucursal del Café
- **Fecha:** Julio 2026
- **Venue:** Palmetto Plaza, Cali, Colombia
- **Organizadores:** Médium Café + Elixir Café
- **Segmento:** Café de especialidad — expositores, tostadores, productores, público general y compradores

## Tipos de Documentos

### Propuestas Comerciales para Stands
- Siempre incluir: nombre del paquete, dimensiones del stand, precio, lista de incluidos, condiciones de pago, fecha límite de inscripción
- Manejar al menos 3 categorías: Básico / Estándar / Premium (o equivalentes)
- Precios en COP. Si hay versión en USD, usar tasa de referencia vigente
- Tono: profesional pero cálido, orientado a comunidad cafetera

### Planos y Distribución
- Describir zonas por nombre: zona expositores, zona de catas, escenario, acceso público, etc.
- Indicar capacidad aproximada por zona cuando sea relevante

### Cronogramas y Timelines
- Formato de tabla con columnas: Fecha / Actividad / Responsable / Estado
- Incluir hitos clave: apertura de inscripciones, cierre, montaje, evento, desmontaje

### Comunicaciones
- Correos a expositores: directos, con call to action claro
- Comunicados de prensa: tono institucional, mencionar ambos organizadores

## Estilo Visual y de Marca
- Paleta sugerida: tonos tierra, café, crema, verde selva
- Tipografía: seria pero con carácter
- Todo documento debe sentirse dentro del ecosistema del café de especialidad colombiano

## Reglas Generales
- Siempre mencionar ambos organizadores (Médium Café y Elixir Café) en documentos oficiales
- Formato carta (Letter) para PDFs y Word
- Márgenes mínimos de 2cm — ningún contenido tocando bordes
