---
name: maquila-cotizacion
description: Usar este skill para todo lo relacionado con cotizaciones de maquila de café especialidad, especialmente para Ghost Coffee y operaciones en Bruselas, Huila. Cubre: construcción o edición de archivos Excel de cotización, hojas de costos internos vs cliente, mermas diferenciadas por tipo de café, dropdowns de líneas, y cualquier cálculo de costos de procesamiento/maquila. Activar cuando Pablo mencione maquila, Ghost Coffee, cotización de café, costos de trilla, tostión, o archivos Excel de café.
---

# Sistema de Cotización de Maquila de Café

## Contexto

Pablo opera un sistema de cotización para Ghost Coffee — una operación de maquila de café especialidad en Bruselas, Huila. El sistema vive en Excel (actualmente versión 6) y tiene dos capas: una hoja visible para el cliente y una hoja interna con costos reales.

## Arquitectura del archivo Excel (Ghost Coffee v6)

### Hojas del archivo:
1. **Cotización Cliente** — Vista limpia para entregar al cliente
   - Líneas de servicio con dropdown
   - Precios por unidad y totales
   - Sin costos internos visibles
2. **Costos Internos** — Hoja oculta o protegida
   - Costos reales por proceso
   - Margen calculado automáticamente
   - No se entrega al cliente
3. **Parámetros** — Tabla de referencia
   - Mermas por tipo de café
   - Precios base de servicios
   - Tasas de cambio si aplica

## Tipos de proceso (líneas de cotización)

| Proceso | Descripción | Merma típica |
|---------|-------------|-------------|
| Trilla | Despergaminado de café pergamino | ~18–22% |
| Trilla + Clasificación | Trilla + zarandeo por tamaño | ~20–25% |
| Tostión | Café verde a tostado | ~15–18% |
| Tostión + Molienda | Café verde a molido | ~16–20% |
| Empaque | Solo empaque en bolsa con válvula | Variable |
| Proceso completo | Trilla + tostión + molienda + empaque | Suma de etapas |

> Las mermas exactas varían por variedad y humedad. Siempre usar las que Pablo confirme.

## Lógica de cálculo

```
Cantidad entrada (kg pergamino o verde)
× (1 - merma%) = Cantidad salida (kg café procesado)
× precio por kg del servicio = Subtotal
+ costos fijos (empaque, etiquetas, etc.) = Total cotización
```

## Estándares del archivo

- **Formato:** .xlsx (no .xls, no .csv)
- **Dropdowns:** Validación de datos en columna "Proceso" — lista desplegable
- **Colores:** Fila de encabezado oscura, filas alternas claras
- **Moneda:** COP por defecto; USD si el cliente es internacional
- **Totales:** Con fórmulas SUM, no valores hardcodeados
- **Hoja cliente:** Sin columnas de costo interno — solo servicio, cantidad, precio unitario, total

## Instrucciones al usar este skill

1. Leer el skill `xlsx` antes de crear o modificar archivos Excel
2. Preguntar a Pablo: ¿cliente nuevo o actualización de cotización existente?
3. Si es actualización, preguntar qué versión tiene actualmente y qué cambió
4. Nunca poner costos internos en la hoja del cliente
5. Siempre proteger la hoja de costos internos con contraseña si Pablo lo indica
6. Preguntar mermas específicas antes de calcular — no asumir porcentajes
7. Si hay precios en USD, incluir columna de TRM (tasa de cambio) referenciada desde celda paramétrica
